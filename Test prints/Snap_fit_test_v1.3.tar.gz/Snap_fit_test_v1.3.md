I didn't change the models. I just printed the newest version with wooden supports instead. And the overhang quality improved by miles.

Good news: they fit together very well when you silde them together.

Bad news: when you try to snap them together (like you're actually supposed to) the male part shatters into pieces.
