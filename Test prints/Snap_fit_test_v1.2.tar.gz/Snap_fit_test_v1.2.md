I made the changes described in the last version. I can't actually test it, because the supports have proven to be impossible to remove properly. I need to make supports out of wood instead.
