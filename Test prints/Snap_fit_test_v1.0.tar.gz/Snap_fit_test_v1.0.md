This is a first test of the snap fit. It probably wont work since the dimensions on both parts are exactly the same, but I can still learn from it.

So, I've learnt 2 things
- I need to print it with supports
- It's super hard to push them together
