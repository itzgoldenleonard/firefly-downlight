So I wanna test a bunch of things here

- Do the dovetails fit
No, they dont. But I dont think these dovetails are the culprit, I think it's the females that need changing. Which really sucks, I was really hoping that I didnt need to, but I do.

- How does the light look
It looks great actually.

- Is the thickness right
Yes, it's a bit thicker than it needs to be which leaves just enough material to remove while sanding.

- How do the rounded corners look
They need support, but with support and a hell of a lot of sanding they're gonna work according to intention and without any dark spots.

- Is the height right
Now this is the second controversial thing. 25mm is really tall, but it also means that I wont get any spots, even without a second layer of diffuser, and I think that a second layer diffuser might not look as good. So this might actually be the best solution, and the simplest one. But maybe only 20mm.
