I am testing a few things here:
- How well do the dovetails fit together
Not very, the male dovetails need a slightly taller body, they dont go together at all

- If they do fit together, how strong is it
Surprisingly strong, but it should be fairly trivial to make it considerably stronger at the expense of improving the print quality

- How well does the stop block work
I can't test that

- How well do the locking nubs work
I also can't test *that*
