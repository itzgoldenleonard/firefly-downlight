I made the male body 0.3mm thinner. I also fixed it so that the base plate is actually at the base and not 2mm into the hook. I also added supports.

So one thing I think I'll do is to make the head of the male one a little shorter, in turn making the body a little longer. It doesnt seem to need more space horizontally, only vertically. It also doesnt bend nearly enough, I think I'll have to make the body even thinner.

The support on the female one is really really difficult to get out, I'll need to find some better solution to make it easier to remove.
