In this version I am trying out the proposed changes from last time

The new height looks good, it still gets rid of all spots but it's not quite as thick

The rounds can still be a bit problematic, one of them turned out great, the other pretty bad, that'll need some more digging.


Something that I'm also doing here is printing tests of the female dovetails but with different changes to find one that actually works.

# `dovetail variation 1`

Exactly the same as the one in the prototype lamp, just checking that the test print does in fact end up as bad as the real thing

And it does

# `dovetail variation 2`

This one I'm extending the top face of the head by 2 layers, so that it has 2 layers to fuck up with the bridge without interfering with the important bits.

But this does actually work, 2 layers is enough that it can slide on, but it still just isn't bridging properly.

# `dovetail variation 3`

The same as variation 2, but with thick bridges enabled

It's more consistent, but not actually any better, worse in fact, but the bridges do seem to make it all the way over more often.

# `dovetail variation 4`

The same as variation 3, but with bridge flow ratio reduced to 0.8

This time it combined the worst of variation 3 and 2.

# `dovetail variation 5`

The same as variation 4, but with the bridging speed lowered to 40mm/s

# `dovetail variation 6`

The same as variation 2, but with the bridge flow ratio increased to 1.2

nope

# `dovetail variation 7`

The same as variation 6, but with the bridging speed lowered to 20mm/s

nooooo
