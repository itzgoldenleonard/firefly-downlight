Here I am testing 3 things:

1. What surfaces make sense to iron
None of the surfaces on the female mount make sense to iron.

2. I made the locking nubs 0.1mm shorter, was that smart
No that was dumb, it's too weak now. Revert it. If it needs to be a little weaker I can sand the nubs

3. How strong is it
