Here I am testing 3 things:

1. What surfaces make sense to iron
None of the surfaces on the female mount make sense to iron.

On the male mount though, all of the top surfaces except the top of the base cube do make sense to iron. Also it might be smart to raise the wall height of the lamp by 0.3-0.5mm to compensate for the tape, I'll have to measure more precisely though.

2. I made the locking nubs 0.1mm shorter, was that smart
No that was dumb, it's too weak now. Revert it. If it needs to be a little weaker I can sand the nubs

3. How strong is it
Right now it's hanging with 600g of weight on it. It's currently not going anywhere, even pulling on it, it's absolutely rock solid. I'll check back on it in a couple of days though.
