Last revision I just pulled some dimensions out of my ass randomly. This time I've given them a bit more thought, and I made it a lot thicker (horizontally only of course).

I'm testing all the same things again. And the results are actually the exact same.
