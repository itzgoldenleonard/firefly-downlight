So what I'm gonna do now is: I'm gonna make 2 different variations. I only need to reprint the male part, so I'm gonna make a variation 1, where the only thing different from v1.3 is that the `head_height` is 0.8, instead of 0.9. And I'm gonna make a variation 2, where the difference is that `body_height` is 0.6, not 0.8.

So I think that I'm gonna need to do a combination, and also, the very top layers are giving me some real print quality issues.
