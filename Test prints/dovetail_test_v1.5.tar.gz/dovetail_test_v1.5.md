I did both of the changes from v1.4 and I chopped 0.2mm off of the sharp edges at the very top of the male dovetail. I'll only print a male again this time

Oh yeah, it fits just right now. But perhaps the locking nub is a bit too locking, maybe it's more appropriate once you can get some more grip on the male part, but right now it's too tight. I think that's just gonna have to be fixed with some indivadual sanding though, it's really not very much material that needs to be removed
