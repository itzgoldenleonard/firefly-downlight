This time I'm making the entire mount as it will be in the lamp. I won't be ironing it, or testing the strength. This test print is mostly just to see if everything fits together like it should.

It almost does. The new design works quite well, but the dovetails themselves have a bit of work left to do.
