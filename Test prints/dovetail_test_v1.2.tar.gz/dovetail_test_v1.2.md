I made no changes to the female. I increased the `body_height` of the male by 0.2mm, and I'm printing it with ample cooling.

And it works absolutely great. I might wanna do some ironing on some of the surfaces for a high quality print, but these dimensions seem good.
