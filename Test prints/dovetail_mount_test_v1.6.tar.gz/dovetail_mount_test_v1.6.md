I changed the width of the lamp, so I'm just re-testing that everything does fit as well together as before. Also I can get to try out the proper ironing and see if that's cool.

It all seems to fit just as well as before. The ironing seems to work well, but the male does still need some extra cooling.
