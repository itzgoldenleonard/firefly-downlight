So bridging sucks right. New approach then, dont use bridging. I'm trying to print it with overhangs this time. Fingers crossed.

# `dovetail variation 1`

It looks very promising

# `dovetail variation 2`

This time I'll try to give it 2 layers instead of 1 before closing it up.

And that's what it took. After 9 attempts I finally cracked it. It might not print out perfectly every time, but if it does make a mistake that's easy to correct with a knife.
